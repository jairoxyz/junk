__scriptname__ = "TESTER"
__author__ = "jairoxyz"
__scriptid__ = "plugin.video.sltester"
__version__ = "1.0.0"

import xbmc,xbmcplugin,xbmcgui,xbmcaddon,sys,os,traceback,urllib


try:
    import Cryptodome
    sys.modules['Crypto'] = Cryptodome
except ImportError:
    pass

from streamlink import Streamlink
from streamlink.plugin.api import useragents

#from dsp import streamlink_proxy

def addPlayLink(name, url, mode):
    u = (sys.argv[0] +
         "?url=" + urllib.quote_plus(url) +
         "&mode=" + str(mode) +
         "&name=" + urllib.quote_plus(name))
    ok = True
    liz = xbmcgui.ListItem(name)
    liz.setInfo('video', {'Title': str(name)})
    liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, liz, False)
    return ok

def INDEX():    
    MAIN('http://www.rtve.es/directo/canal-24h')

def MAIN(url):
    addPlayLink('StreamLink RTVE plugin test', url, 1)  
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def PLAY(url, title):
    listitem = xbmcgui.ListItem(str(title))
    listitem.setInfo('video', {'Title': str(title)})
    try:
        # slProxy = streamlink_proxy.SLProxy_Helper()
        # url = slProxy.resolve_url(urllib.quote(url))
        sl = Streamlink()
        sl.set_loglevel("debug")
        sl.set_logoutput(sys.stdout)
        sl.set_option('http-headers', {"User-Agent": useragents.CHROME})
        plugin = sl.resolve_url(url)
        xbmc.log('[StreamLink] Found matching plugin %s for URL %s'%(plugin.module, url))
        streams = plugin.streams()
        stream = streams.get('best')
        url = stream.url
        xbmc.log('[StreamLink] resolved url: %s'%str(url))
    except Exception as err:
        traceback.print_exc(file=sys.stdout)
        xbmc.log('[StreamLink] An error occured: %s'%str(err.message))
        dialog = xbmcgui.Dialog()
        dialog.ok('Error', err.message)
    
    listitem.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    
def getParams():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param



params = getParams()
url = None
name = None
mode = None


try: url = urllib.unquote_plus(params["url"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: mode = int(params["mode"])
except: pass

if mode is None: INDEX()
elif mode == 0: MAIN(url)
elif mode == 1: PLAY(url, name)